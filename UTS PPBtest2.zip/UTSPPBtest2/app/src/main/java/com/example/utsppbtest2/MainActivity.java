package com.example.utsppbtest2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    String[] detailedDescription = {"Nasi Goreng asli Indonesia, dengan berbagai rempah-rempah pilihan." +
            "Harga: Rp.50.000",
            "Kwetiaw goreng warisan keluarga yang di lengkapi dengan berbagai macam bumbu-bumbu herbal yang baik untuk tubuh." +
                    "Harga: Rp.30.000",
            "Ikang bakar gurami yang di panggan gmenggunakan panggangan tradisional sehingga membuat rasa ikan menjadi lebih gurih dan nikmat." +
                    "Harga: Rp.40.000",
            "Sate ayam yang di bakar menggunakan panggangan tradisional khas indonesia, dan di taburi oleh bumbu-bumbu alami." +
                    "Harga: Rp.25.000"};
    String[] programName = {"Nasi Goreng", "Kwetiaw goreng","Ikan Bakar", "Sate"};
    String[] programDescription ={"Deskripsi Nasi Goreng", "Deskripsi Kwetiaw goreng","Deskripsi Ikan Bakar", "Descripsi Sate"};
    int[] programImages = {R.drawable.nasi_goreng,R.drawable.kwetiaw_goreng,R.drawable.ikan_bakar,R.drawable.sate};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView.findViewById(R.id.listview);
        CustomAdapter customAdapter = new CustomAdapter();
        listView.setAdapter(customAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),ListdataActivity.class);
                intent.putExtra("makanan", programName[1]);
                intent.putExtra("gambar", programImages[1]);
                intent.putExtra("desc", programDescription[1]);
                intent.putExtra("desc", detailedDescription[1]);
                startActivity(intent);
            }
                                    });

    }

    private class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return programImages.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            @SuppressLint({"ViewHolder", "InflateParams"}) View view1 = getLayoutInflater().inflate(R.layout.row_data,null);
            TextView makanan = view1.findViewById(R.id.textview1);
            TextView description = view1.findViewById(R.id.textview2);
            TextView detail = view1.findViewById(R.id.textView3);
            ImageView gambar = view1.findViewById(R.id.imageView);

            makanan.setText(programName[1]);
            description.setText(programDescription[1]);
            detail.setText(detailedDescription[1]);
            gambar.setImageResource(programImages[1]);

            return view1;
        }
    }
}