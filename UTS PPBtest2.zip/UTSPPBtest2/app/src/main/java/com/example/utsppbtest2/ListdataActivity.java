package com.example.utsppbtest2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ListdataActivity extends AppCompatActivity {
ImageView imageView;
TextView textView1;
TextView textView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listdata);

        imageView = findViewById(R.id.imageView);
        textView1 = findViewById(R.id.textview1);
        textView3 = findViewById(R.id.textView3);

        Intent intent = getIntent();
        textView1.setText(intent.getStringExtra("Makanan"));
        textView3.setText(intent.getStringExtra("deskripsi"));
        imageView.setImageResource(intent.getIntExtra("image", 0));

    }
}